import os
import imaplib
import email
import pandas
import re

HOST = "imap.gmail.com"
USERNAME = os.environ.get("MAIL_USER")
PASSWORD = os.environ.get("MAIL_PASS")


def get_inbox():
    mail = imaplib.IMAP4_SSL(HOST)
    mail.login(USERNAME, PASSWORD)
    mail.select("inbox")
    _, search_data = mail.search(None, "SEEN")
    my_message = []
    for num in search_data[0].split():
        email_data = {}
        _, data = mail.fetch(num, "(RFC822)")
        _, b = data[0]
        email_message = email.message_from_bytes(b)
        for header in ["from", "subject", "date"]:
            email_data[header] = email_message[header]
        for part in email_message.walk():
            if part.get_content_type() == "text/plain":
                body = part.get_payload(decode=True)
                email_data["body"] = body.decode()
        my_message.append(email_data)
    return my_message


if __name__ == "__main__":
    my_inbox = get_inbox()
    with open("test.csv", mode="w") as emptyfy:
        emptyfy.write("")

    keywords = ["account", "active", "bankrupted", "business", "client", "euroclear", "holding", "investor",
                "investors", "legal", "owners", "registered", "restriction", "share", "shareholder",
                "suspended", "when"]

    send_and_key = []

    for message in my_inbox:
        df = pandas.DataFrame(message, index=[0])
        df.to_csv("./test.csv", mode="a", index=False)

    # TODO:   Need to safe condition while empty csv
    data_from_csv = pandas.read_csv("test.csv", sep=",")

    buid_regex = re.compile(r"\d\d\d\d\d\d\d-\d")
    client_regex = re.compile(r"\d\d\d\d\d\d-([A-Z])?\d\d\d")
    instrument_regex = re.compile(r"[A-Z][A-Z]\d\d\d\d\d\d\d\d\d\d")
    # shareholder_regex = re.compile(r"([A-Z][A-Z][A-Z][A-Z][A-Z][A-Z][A-Z][A-Z])?")

    for i in data_from_csv.index:
        body_content = data_from_csv["body"][i]
        body_content_list = body_content.split()
        # print(body_content_list)
        values = []
        Dict_value = {}
        for key in body_content_list:
            buid = buid_regex.search(key)
            client = client_regex.search(key)
            instrument = instrument_regex.search(key)
            if buid is not None:
                values.append(buid.group())
            if client is not None:
                values.append(client.group())
            if instrument is not None:
                values.append(instrument.group())
            if key.lower() in keywords:
                values.append(key)
            Dict_value = {"email": data_from_csv["from"][i], "keywords": values}

        send_and_key.append(Dict_value)

    email_keyword_df = pandas.DataFrame(send_and_key)
    email_keyword_df = email_keyword_df[email_keyword_df["email"] != "from"]
    print(email_keyword_df)
    email_keyword_df.to_csv("./email_keyword.csv", mode="w", index=False)
